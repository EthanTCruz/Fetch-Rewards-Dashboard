from Fetch_Dash.classes.FlaskDash import ReceiptsDashboard

def run():
    app = ReceiptsDashboard()
    app.Run()

